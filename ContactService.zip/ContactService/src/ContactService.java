/**
 * Assignment Title: Module 3-2 Milestone
 * Student Name: Darian Gernand
 * Date: 09/22/24
 */
import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contacts;

    public ContactService() {
        contacts = new HashMap<>();
    }

    public boolean addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactID())) {
            return false;
        }
        contacts.put(contact.getContactID(), contact);
        return true;
    }

    public boolean deleteContact(String contactID) {
        if (!contacts.containsKey(contactID)) {
            return false;
        }
        contacts.remove(contactID);
        return true;
    }

    public boolean updateContact(String contactID, String firstName, String lastName, String phone, String address) {
        if (!contacts.containsKey(contactID)) {
            return false;
        }
        Contact contact = contacts.get(contactID);
        if (firstName != null && !firstName.isBlank()) contact.setFirstName(firstName);
        if (lastName != null && !lastName.isBlank()) contact.setLastName(lastName);
        if (phone != null && !phone.isBlank()) contact.setPhone(phone);
        if (address != null && !address.isBlank()) contact.setAddress(address);
        return true;
    }

    public Contact getContact(String contactID) {
        return contacts.get(contactID);
    }
}

